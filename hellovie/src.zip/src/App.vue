<template>
  <router-view>

  </router-view>
</template>

<script>
export default {
  name:"App"
}
</script>
<style>
#app {
  height: 100%;
}
</style>